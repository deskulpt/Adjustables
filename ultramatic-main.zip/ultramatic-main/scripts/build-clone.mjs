import { access, mkdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

const root = new URL('..', import.meta.url).pathname;
const template = await readFile(join(root, 'site-template.html'), 'utf8');

const pages = [
  ['home', '', 'Ultramatic Sleep | Made to rise.', 'Canadian adjustable beds, mattresses, sleep systems and lift chairs designed around the way you sleep, move and live at home.'],
  ['find', 'find-your-bed', 'Find Your Bed | Ultramatic Sleep', 'Answer five practical questions and understand which Ultramatic sleep system fits your life.'],
  ['compare', 'compare', 'Compare Adjustable Beds | Ultramatic Sleep', 'Compare Ultramatic adjustable bases by comfort, control, independence and fit.'],
  ['adjustable-beds', 'shop/adjustable-beds', 'Adjustable Beds | Ultramatic Sleep', 'Adjustable comfort, built around what you need. Explore Ultramatic bases and sleep systems.'],
  ['mattresses', 'shop/mattresses', 'Mattresses | Ultramatic Sleep', 'Mattresses designed to move with the base and support the way you rest.'],
  ['sleep-systems', 'shop/sleep-systems', 'Sleep Systems | Ultramatic Sleep', 'Complete base and mattress pairings designed to move together.'],
  ['lift-chairs', 'shop/lift-chairs', 'Lift Chairs | Ultramatic Sleep', 'Beautiful lift chairs that help everyday movement feel more natural at home.'],
  ['mobility', 'shop/mobility', 'Mobility | Ultramatic Sleep', 'Practical mobility solutions with thoughtful Canadian service.'],
  ['bedding', 'shop/bedding', 'Bedding & Accessories | Ultramatic Sleep', 'Finish your sleep system with compatible bedding and accessories.'],
  ['parts', 'shop/parts', 'Parts & Support | Ultramatic Sleep', 'Find the right parts and support for your Ultramatic system.'],
  ['sleep-better', 'sleep-better', 'Sleep Better | Ultramatic Sleep', 'Sleep better, move easier, and understand your options with Ultramatic guides.'],
  ['sleep-adjustable', 'sleep-better/adjustable-beds', 'Adjustable Bed Guides | Ultramatic Sleep', 'Clear guides to adjustable beds, positions and fit.'],
  ['sleep-health', 'sleep-better/health', 'Health & Comfort Guides | Ultramatic Sleep', 'Understand positions, comfort and mattress compatibility without the jargon.'],
  ['independence', 'sleep-better/independence', 'Independence at Home | Ultramatic Sleep', 'Explore beds, lift chairs and guidance designed to make everyday movement easier.'],
  ['sleep-mattresses', 'sleep-better/mattresses', 'Mattress Compatibility | Ultramatic Sleep', 'Learn what makes a mattress move well with an adjustable base.'],
  ['article', 'sleep-better/adjustable-beds/zero-gravity-explained', 'Zero Gravity Explained | Ultramatic Sleep', 'A practical guide to the zero-gravity position and adjustable sleep.'],
  ['consultation', 'book-a-consultation', 'Book a Fitting | Ultramatic Sleep', 'Talk through your sleep system with a real Ultramatic specialist.'],
  ['showroom', 'showroom', 'Visit the Showroom | Ultramatic Sleep', 'Try the difference in person at Ultramatic.'],
  ['financing', 'financing', 'Financing | Ultramatic Sleep', 'Explore financing questions with a specialist before you choose a system.'],
  ['delivery', 'delivery-and-setup', 'Delivery & Setup | Ultramatic Sleep', 'Understand delivery, installation and old-bed removal before your order arrives.'],
  ['warranty', 'warranty', 'Warranty | Ultramatic Sleep', 'Find warranty information for your Ultramatic products.'],
  ['about', 'about', 'About Ultramatic | Ultramatic Sleep', 'Helping Canadians rest easier since 1982.'],
  ['reviews', 'reviews', 'Reviews | Ultramatic Sleep', 'Read why customers chose Ultramatic for comfort, mobility and everyday life.'],
  ['trade', 'trade', 'Trade In | Ultramatic Sleep', 'Talk to Ultramatic about your next sleep system.'],
  ['product', 'products/postureplus-4-5', 'PosturePlus 4.5 | Ultramatic Sleep', 'A highly adjustable base for more control over position, support and partner comfort.'],
  ['sleep-system', 'products/postureplus-system', 'PosturePlus Sleep System | Ultramatic Sleep', 'A complete sleep system designed to move together.'],
  ['cart', 'cart', 'Your Cart | Ultramatic Sleep', 'Review your Ultramatic sleep system and choose how you want to complete your order.']
];

function render(page, path, title, description) {
  return template
    .replaceAll('__PAGE__', page)
    .replaceAll('__PATH__', `/${path}${path ? '/' : ''}`)
    .replaceAll('__TITLE__', title)
    .replaceAll('__DESCRIPTION__', description);
}

for (const [page, path, title, description] of pages) {
  const outputDir = join(root, path);
  await mkdir(outputDir, { recursive: true });
  await writeFile(join(outputDir, 'index.html'), render(page, path, title, description));
}

await access(join(root, 'clone.css'));
await access(join(root, 'clone.js'));
await access(join(root, 'public', 'assets', 'ultramatic-hero.gif'));
console.log(`Built ${pages.length} Ultramatic routes.`);
